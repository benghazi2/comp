import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const DataContext = createContext();

export const DataProvider = ({ children }) => {
  // حالة البيانات الأساسية
  const [accounts, setAccounts] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [clients, setClients] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // تحميل البيانات عند بدء التطبيق
  useEffect(() => {
    const loadData = async () => {
      try {
        // استرجاع البيانات من التخزين المحلي
        const accountsData = await AsyncStorage.getItem('accounts');
        const transactionsData = await AsyncStorage.getItem('transactions');
        const invoicesData = await AsyncStorage.getItem('invoices');
        const clientsData = await AsyncStorage.getItem('clients');
        const suppliersData = await AsyncStorage.getItem('suppliers');

        // تحويل البيانات إلى كائنات JavaScript
        if (accountsData) setAccounts(JSON.parse(accountsData));
        if (transactionsData) setTransactions(JSON.parse(transactionsData));
        if (invoicesData) setInvoices(JSON.parse(invoicesData));
        if (clientsData) setClients(JSON.parse(clientsData));
        if (suppliersData) setSuppliers(JSON.parse(suppliersData));

        // إذا لم تكن هناك بيانات، قم بتهيئة بعض البيانات الافتراضية
        if (!accountsData) {
          const defaultAccounts = [
            { id: '1', name: 'النقدية', type: 'أصول', balance: 10000, currency: 'ريال' },
            { id: '2', name: 'المبيعات', type: 'إيرادات', balance: 0, currency: 'ريال' },
            { id: '3', name: 'المشتريات', type: 'مصروفات', balance: 0, currency: 'ريال' },
            { id: '4', name: 'الذمم المدينة', type: 'أصول', balance: 0, currency: 'ريال' },
            { id: '5', name: 'الذمم الدائنة', type: 'خصوم', balance: 0, currency: 'ريال' },
          ];
          await AsyncStorage.setItem('accounts', JSON.stringify(defaultAccounts));
          setAccounts(defaultAccounts);
        }
      } catch (error) {
        console.error('خطأ في تحميل البيانات:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, []);

  // وظائف إدارة الحسابات
  const addAccount = async (account) => {
    try {
      const newAccount = {
        id: Date.now().toString(),
        ...account,
        createdAt: new Date().toISOString(),
      };
      const updatedAccounts = [...accounts, newAccount];
      await AsyncStorage.setItem('accounts', JSON.stringify(updatedAccounts));
      setAccounts(updatedAccounts);
      return { success: true, account: newAccount };
    } catch (error) {
      return { success: false, error: 'فشل إضافة الحساب' };
    }
  };

  const updateAccount = async (accountId, updatedData) => {
    try {
      const updatedAccounts = accounts.map(account =>
        account.id === accountId ? { ...account, ...updatedData } : account
      );
      await AsyncStorage.setItem('accounts', JSON.stringify(updatedAccounts));
      setAccounts(updatedAccounts);
      return { success: true };
    } catch (error) {
      return { success: false, error: 'فشل تحديث الحساب' };
    }
  };

  const deleteAccount = async (accountId) => {
    try {
      // التحقق من عدم وجود معاملات مرتبطة بهذا الحساب
      const linkedTransactions = transactions.filter(
        transaction => transaction.fromAccount === accountId || transaction.toAccount === accountId
      );

      if (linkedTransactions.length > 0) {
        return { 
          success: false, 
          error: 'لا يمكن حذف الحساب لأنه مرتبط بمعاملات. قم بحذف المعاملات أولاً.' 
        };
      }

      const updatedAccounts = accounts.filter(account => account.id !== accountId);
      await AsyncStorage.setItem('accounts', JSON.stringify(updatedAccounts));
      setAccounts(updatedAccounts);
      return { success: true };
    } catch (error) {
      return { success: false, error: 'فشل حذف الحساب' };
    }
  };

  // وظائف إدارة المعاملات
  const addTransaction = async (transaction) => {
    try {
      const newTransaction = {
        id: Date.now().toString(),
        ...transaction,
        date: transaction.date || new Date().toISOString(),
        createdAt: new Date().toISOString(),
      };

      // تحديث أرصدة الحسابات
      let updatedAccounts = [...accounts];
      const fromAccountIndex = updatedAccounts.findIndex(a => a.id === transaction.fromAccount);
      const toAccountIndex = updatedAccounts.findIndex(a => a.id === transaction.toAccount);

      if (fromAccountIndex !== -1) {
        updatedAccounts[fromAccountIndex] = {
          ...updatedAccounts[fromAccountIndex],
          balance: updatedAccounts[fromAccountIndex].balance - transaction.amount
        };
      }

      if (toAccountIndex !== -1) {
        updatedAccounts[toAccountIndex] = {
          ...updatedAccounts[toAccountIndex],
          balance: updatedAccounts[toAccountIndex].balance + transaction.amount
        };
      }

      // حفظ المعاملة والحسابات المحدثة
      const updatedTransactions = [...transactions, newTransaction];
      await AsyncStorage.setItem('transactions', JSON.stringify(updatedTransactions));
      await AsyncStorage.setItem('accounts', JSON.stringify(updatedAccounts));
      
      setTransactions(updatedTransactions);
      setAccounts(updatedAccounts);
      
      return { success: true, transaction: newTransaction };
    } catch (error) {
      return { success: false, error: 'فشل إضافة المعاملة' };
    }
  };

  const deleteTransaction = async (transactionId) => {
    try {
      // العثور على المعاملة
      const transaction = transactions.find(t => t.id === transactionId);
      if (!transaction) {
        return { success: false, error: 'المعاملة غير موجودة' };
      }

      // عكس تأثير المعاملة على الحسابات
      let updatedAccounts = [...accounts];
      const fromAccountIndex = updatedAccounts.findIndex(a => a.id === transaction.fromAccount);
      const toAccountIndex = updatedAccounts.findIndex(a => a.id === transaction.toAccount);

      if (fromAccountIndex !== -1) {
        updatedAccounts[fromAccountIndex] = {
          ...updatedAccounts[fromAccountIndex],
          balance: updatedAccounts[fromAccountIndex].balance + transaction.amount
        };
      }

      if (toAccountIndex !== -1) {
        updatedAccounts[toAccountIndex] = {
          ...updatedAccounts[toAccountIndex],
          balance: updatedAccounts[toAccountIndex].balance - transaction.amount
        };
      }

      // حذف المعاملة وتحديث الحسابات
      const updatedTransactions = transactions.filter(t => t.id !== transactionId);
      await AsyncStorage.setItem('transactions', JSON.stringify(updatedTransactions));
      await AsyncStorage.setItem('accounts', JSON.stringify(updatedAccounts));
      
      setTransactions(updatedTransactions);
      setAccounts(updatedAccounts);
      
      return { success: true };
    } catch (error) {
      return { success: false, error: 'فشل حذف المعاملة' };
    }
  };

  // وظائف إدارة الفواتير
  const addInvoice = async (invoice) => {
    try {
      const newInvoice = {
        id: Date.now().toString(),
        ...invoice,
        date: invoice.date || new Date().toISOString(),
        status: invoice.status || 'غير مدفوعة',
        createdAt: new Date().toISOString(),
      };

      const updatedInvoices = [...invoices, newInvoice];
      await AsyncStorage.setItem('invoices', JSON.stringify(updatedInvoices));
      setInvoices(updatedInvoices);

      // إذا كانت الفاتورة مدفوعة، قم بإنشاء معاملة مالية
      if (invoice.status === 'مدفوعة' && invoice.paymentAccount) {
        const clientAccount = clients.find(c => c.id === invoice.clientId)?.accountId;
        if (clientAccount) {
          await addTransaction({
            fromAccount: clientAccount,
            toAccount: invoice.paymentAccount,
            amount: invoice.total,
            description: `دفع الفاتورة رقم ${newInvoice.id}`,
            date: new Date().toISOString(),
          });
        }
      }

      return { success: true, invoice: newInvoice };
    } catch (error) {
      return { success: false, error: 'فشل إضافة الفاتورة' };
    }
  };

  const updateInvoiceStatus = async (invoiceId, status, paymentAccount) => {
    try {
      const updatedInvoices = invoices.map(invoice => {
        if (invoice.id === invoiceId) {
          return { ...invoice, status, updatedAt: new Date().toISOString() };
        }
        return invoice;
      });

      await AsyncStorage.setItem('invoices', JSON.stringify(updatedInvoices));
      setInvoices(updatedInvoices);

      // إذا تم تحديث الحالة إلى مدفوعة، قم بإنشاء معاملة مالية
      if (status === 'مدفوعة') {
        const invoice = invoices.find(inv => inv.id === invoiceId);
        const clientAccount = clients.find(c => c.id === invoice.clientId)?.accountId;
        
        if (invoice && clientAccount && paymentAccount) {
          await addTransaction({
            fromAccount: clientAccount,
            toAccount: paymentAccount,
            amount: invoice.total,
            description: `دفع الفاتورة رقم ${invoiceId}`,
            date: new Date().toISOString(),
          });
        }
      }

      return { success: true };
    } catch (error) {
      return { success: false, error: 'فشل تحديث حالة الفاتورة' };
    }
  };

  // وظائف إدارة العملاء
  const addClient = async (client) => {
    try {
      // إنشاء حساب للعميل
      const accountResult = await addAccount({
        name: `حساب العميل - ${client.name}`,
        type: 'ذمم مدينة',
        balance: 0,
        currency: 'ريال',
      });

      if (!accountResult.success) {
        return { success: false, error: 'فشل إنشاء حساب للعميل' };
      }

      const newClient = {
        id: Date.now().toString(),
        ...client,
        accountId: accountResult.account.id,
        createdAt: new Date().toISOString(),
      };

      const updatedClients = [...clients, newClient];
      await AsyncStorage.setItem('clients', JSON.stringify(updatedClients));
      setClients(updatedClients);

      return { success: true, client: newClient };
    } catch (error) {
      return { success: false, error: 'فشل إضافة العميل' };
    }
  };

  const updateClient = async (clientId, updatedData) => {
    try {
      const updatedClients = clients.map(client =>
        client.id === clientId ? { ...client, ...updatedData, updatedAt: new Date().toISOString() } : client
      );

      await AsyncStorage.setItem('clients', JSON.stringify(updatedClients));
      setClients(updatedClients);

      return { success: true };
    } catch (error) {
      return { success: false, error: 'فشل تحديث بيانات العميل' };
    }
  };

  const deleteClient = async (clientId) => {
    try {
      // التحقق من عدم وجود فواتير مرتبطة بهذا العميل
      const linkedInvoices = invoices.filter(invoice => invoice.clientId === clientId);

      if (linkedInvoices.length > 0) {
        return { 
          success: false, 
          error: 'لا يمكن حذف العميل لأنه مرتبط بفواتير. قم بحذف الفواتير أولاً.' 
        };
      }

      // الحصول على معرف حساب العميل
      const client = clients.find(c => c.id === clientId);
      if (client && client.accountId) {
        // حذف حساب العميل
        await deleteAccount(client.accountId);
      }

      const updatedClients = clients.filter(client => client.id !== clientId);
      await AsyncStorage.setItem('clients', JSON.stringify(updatedClients));
      setClients(updatedClients);

      return { success: true };
    } catch (error) {
      return { success: false, error: 'فشل حذف العميل' };
    }
  };

  // وظائف إدارة الموردين
  const addSupplier = async (supplier) => {
    try {
      // إنشاء حساب للمورد
      const accountResult = await addAccount({
        name: `حساب المورد - ${supplier.name}`,
        type: 'ذمم دائنة',
        balance: 0,
        currency: 'ريال',
      });

      if (!accountResult.success) {
        return { success: false, error: 'فشل إنشاء حساب للمورد' };
      }

      const newSupplier = {
        id: Date.now().toString(),
        ...supplier,
        accountId: accountResult.account.id,
        createdAt: new Date().toISOString(),
      };

      const updatedSuppliers = [...suppliers, newSupplier];
      await AsyncStorage.setItem('suppliers', JSON.stringify(updatedSuppliers));
      setSuppliers(updatedSuppliers);

      return { success: true, supplier: newSupplier };
    } catch (error) {
      return { success: false, error: 'فشل إضافة المورد' };
    }
  };

  // وظائف التقارير
  const generateIncomeStatement = (startDate, endDate) => {
    // تحويل التواريخ إلى كائنات Date
    const start = new Date(startDate);
    const end = new Date(endDate);

    // تصفية المعاملات حسب النطاق الزمني
    const filteredTransactions = transactions.filter(transaction => {
      const transactionDate = new Date(transaction.date);
      return transactionDate >= start && transactionDate <= end;
    });

    // حساب الإيرادات والمصروفات
    let revenues = 0;
    let expenses = 0;

    filteredTransactions.forEach(transaction => {
      const fromAccount = accounts.find(account => account.id === transaction.fromAccount);
      const toAccount = accounts.find(account => account.id === transaction.toAccount);

      if (fromAccount && fromAccount.type === 'مصروفات') {
        expenses += transaction.amount;
      }

      if (toAccount && toAccount.type === 'إيرادات') {
        revenues += transaction.amount;
      }
    });

    // حساب صافي الربح
    const netIncome = revenues - expenses;

    return {
      startDate,
      endDate,
      revenues,
      expenses,
      netIncome,
    };
  };

  const generateBalanceSheet = () => {
    // تصنيف الحسابات
    const assets = accounts.filter(account => account.type === 'أصول' || account.type === 'ذمم مدينة');
    const liabilities = accounts.filter(account => account.type === 'خصوم' || account.type === 'ذمم دائنة');
    
    // حساب إجمالي الأصول والخصوم
    const totalAssets = assets.reduce((sum, account) => sum + account.balance, 0);
    const totalLiabilities = liabilities.reduce((sum, account) => sum + account.balance, 0);
    
    // حساب حقوق الملكية
    const equity = totalAssets - totalLiabilities;
    
    return {
      date: new Date().toISOString(),
      assets,
      totalAssets,
      liabilities,
      totalLiabilities,
      equity,
    };
  };

  return (
    <DataContext.Provider
      value={{
        // البيانات
        accounts,
        transactions,
        invoices,
        clients,
        suppliers,
        isLoading,
        
        // وظائف إدارة الحسابات
        addAccount,
        updateAccount,
        deleteAccount,
        
        // وظائف إدارة المعاملات
        addTransaction,
        deleteTransaction,
        
        // وظائف إدارة الفواتير
        addInvoice,
        updateInvoiceStatus,
        
        // وظائف إدارة العملاء
        addClient,
        updateClient,
        deleteClient,
        
        // وظائف إدارة الموردين
        addSupplier,
        
        // وظائف التقارير
        generateIncomeStatement,
        generateBalanceSheet,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};
