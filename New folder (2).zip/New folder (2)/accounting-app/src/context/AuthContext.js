import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [userToken, setUserToken] = useState(null);
  const [userInfo, setUserInfo] = useState(null);

  useEffect(() => {
    // فحص إذا كان المستخدم مسجل الدخول مسبقاً
    const bootstrapAsync = async () => {
      try {
        const token = await AsyncStorage.getItem('userToken');
        const userInfoString = await AsyncStorage.getItem('userInfo');
        
        if (token && userInfoString) {
          setUserToken(token);
          setUserInfo(JSON.parse(userInfoString));
        }
      } catch (e) {
        console.log('خطأ في استرجاع بيانات المستخدم:', e);
      } finally {
        setIsLoading(false);
      }
    };

    bootstrapAsync();
  }, []);

  const login = async (email, password) => {
    // في التطبيق الحقيقي، هنا يتم الاتصال بالخادم للتحقق من بيانات المستخدم
    // هذا مثال بسيط للتوضيح فقط
    try {
      // بيانات المستخدم الافتراضية للتجربة
      const userData = {
        id: '1',
        name: 'مستخدم تجريبي',
        email: email,
        companyName: 'شركتي للمحاسبة',
      };

      const fakeToken = 'token-123456';
      
      // حفظ بيانات المستخدم في التخزين المحلي
      await AsyncStorage.setItem('userToken', fakeToken);
      await AsyncStorage.setItem('userInfo', JSON.stringify(userData));
      
      setUserInfo(userData);
      setUserToken(fakeToken);
      
      return { success: true };
    } catch (error) {
      return { success: false, error: 'فشل تسجيل الدخول' };
    }
  };

  const logout = async () => {
    try {
      await AsyncStorage.removeItem('userToken');
      await AsyncStorage.removeItem('userInfo');
      setUserToken(null);
      setUserInfo(null);
      return { success: true };
    } catch (error) {
      return { success: false, error: 'فشل تسجيل الخروج' };
    }
  };

  const register = async (name, email, password, companyName) => {
    // في التطبيق الحقيقي، هنا يتم إرسال بيانات التسجيل إلى الخادم
    try {
      const userData = {
        id: Date.now().toString(),
        name,
        email,
        companyName,
      };

      const fakeToken = 'token-' + Date.now();
      
      await AsyncStorage.setItem('userToken', fakeToken);
      await AsyncStorage.setItem('userInfo', JSON.stringify(userData));
      
      setUserInfo(userData);
      setUserToken(fakeToken);
      
      return { success: true };
    } catch (error) {
      return { success: false, error: 'فشل إنشاء الحساب' };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        isLoading,
        userToken,
        userInfo,
        login,
        logout,
        register,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
