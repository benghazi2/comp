import React, { useState, useEffect, useContext } from 'react';
import { View, StyleSheet, ScrollView, Alert } from 'react-native';
import { TextInput, Button, Text, Card, RadioButton } from 'react-native-paper';
import { DataContext } from '../../context/DataContext';

export default function AddAccountScreen({ route, navigation }) {
  const { accountId } = route.params || {};
  const { accounts, addAccount, updateAccount } = useContext(DataContext);
  
  const [name, setName] = useState('');
  const [type, setType] = useState('أصول');
  const [balance, setBalance] = useState('0');
  const [currency, setCurrency] = useState('ريال');
  const [loading, setLoading] = useState(false);
  
  const isEditMode = !!accountId;
  
  useEffect(() => {
    if (isEditMode) {
      const accountToEdit = accounts.find(acc => acc.id === accountId);
      if (accountToEdit) {
        setName(accountToEdit.name);
        setType(accountToEdit.type);
        setBalance(accountToEdit.balance.toString());
        setCurrency(accountToEdit.currency);
      }
    }
  }, [accountId]);
  
  const handleSave = async () => {
    if (!name || !type || !balance || !currency) {
      Alert.alert('خطأ', 'الرجاء إدخال جميع البيانات المطلوبة');
      return;
    }
    
    const balanceValue = parseFloat(balance);
    if (isNaN(balanceValue)) {
      Alert.alert('خطأ', 'الرجاء إدخال قيمة رصيد صحيحة');
      return;
    }
    
    setLoading(true);
    
    try {
      const accountData = {
        name,
        type,
        balance: balanceValue,
        currency,
      };
      
      if (isEditMode) {
        const result = await updateAccount(accountId, accountData);
        if (result.success) {
          Alert.alert('نجاح', 'تم تحديث الحساب بنجاح');
          navigation.goBack();
        } else {
          Alert.alert('خطأ', result.error || 'فشل تحديث الحساب');
        }
      } else {
        const result = await addAccount(accountData);
        if (result.success) {
          Alert.alert('نجاح', 'تم إضافة الحساب بنجاح');
          navigation.goBack();
        } else {
          Alert.alert('خطأ', result.error || 'فشل إضافة الحساب');
        }
      }
    } catch (error) {
      Alert.alert('خطأ', 'حدث خطأ أثناء حفظ الحساب');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Card style={styles.card}>
        <Card.Content>
          <Text style={styles.title}>
            {isEditMode ? 'تعديل الحساب' : 'إضافة حساب جديد'}
          </Text>
          
          <TextInput
            label="اسم الحساب"
            value={name}
            onChangeText={setName}
            mode="outlined"
            style={styles.input}
            right={<TextInput.Icon name="account" />}
          />
          
          <Text style={styles.sectionTitle}>نوع الحساب</Text>
          <View style={styles.radioGroup}>
            <RadioButton.Group onValueChange={setType} value={type}>
              <View style={styles.radioItem}>
                <Text>أصول</Text>
                <RadioButton value="أصول" />
              </View>
              <View style={styles.radioItem}>
                <Text>خصوم</Text>
                <RadioButton value="خصوم" />
              </View>
              <View style={styles.radioItem}>
                <Text>إيرادات</Text>
                <RadioButton value="إيرادات" />
              </View>
              <View style={styles.radioItem}>
                <Text>مصروفات</Text>
                <RadioButton value="مصروفات" />
              </View>
            </RadioButton.Group>
          </View>
          
          <TextInput
            label="الرصيد الافتتاحي"
            value={balance}
            onChangeText={setBalance}
            mode="outlined"
            style={styles.input}
            keyboardType="numeric"
            right={<TextInput.Icon name="cash" />}
          />
          
          <TextInput
            label="العملة"
            value={currency}
            onChangeText={setCurrency}
            mode="outlined"
            style={styles.input}
            right={<TextInput.Icon name="currency-usd" />}
          />
          
          <Button 
            mode="contained" 
            onPress={handleSave} 
            style={styles.button}
            loading={loading}
            disabled={loading}
          >
            {isEditMode ? 'حفظ التعديلات' : 'إضافة الحساب'}
          </Button>
        </Card.Content>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 10,
  },
  card: {
    marginBottom: 15,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'right',
  },
  radioGroup: {
    marginBottom: 15,
  },
  radioItem: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 5,
  },
  button: {
    marginTop: 10,
    paddingVertical: 5,
  },
});
