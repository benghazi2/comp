import React, { useState, useContext, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Alert } from 'react-native';
import { Text, Button, Card, TextInput, Picker } from 'react-native-paper';
import { DataContext } from '../../context/DataContext';
import DateTimePicker from '@react-native-community/datetimepicker';

const AddTransactionScreen = ({ route, navigation }) => {
  const { transactionId } = route.params || {};
  const { accounts, transactions, addTransaction } = useContext(DataContext);
  
  const [fromAccount, setFromAccount] = useState('');
  const [toAccount, setToAccount] = useState('');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const isEditMode = !!transactionId;
  
  useEffect(() => {
    if (isEditMode) {
      const transactionToEdit = transactions.find(t => t.id === transactionId);
      if (transactionToEdit) {
        setFromAccount(transactionToEdit.fromAccount || '');
        setToAccount(transactionToEdit.toAccount || '');
        setAmount(transactionToEdit.amount.toString());
        setDescription(transactionToEdit.description || '');
        setDate(new Date(transactionToEdit.date));
      }
    }
  }, [transactionId]);
  
  const handleSave = async () => {
    if (!fromAccount || !toAccount || !amount || !description) {
      Alert.alert('خطأ', 'الرجاء إدخال جميع البيانات المطلوبة');
      return;
    }
    
    const amountValue = parseFloat(amount);
    if (isNaN(amountValue) || amountValue <= 0) {
      Alert.alert('خطأ', 'الرجاء إدخال مبلغ صحيح');
      return;
    }
    
    setLoading(true);
    
    try {
      const transactionData = {
        fromAccount,
        toAccount,
        amount: amountValue,
        description,
        date: date.toISOString(),
      };
      
      const result = await addTransaction(transactionData);
      
      if (result.success) {
        Alert.alert('نجاح', 'تم إضافة المعاملة بنجاح');
        navigation.goBack();
      } else {
        Alert.alert('خطأ', result.error || 'فشل إضافة المعاملة');
      }
    } catch (error) {
      Alert.alert('خطأ', 'حدث خطأ أثناء حفظ المعاملة');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };
  
  const onChangeDate = (event, selectedDate) => {
    setShowDatePicker(false);
    if (selectedDate) {
      setDate(selectedDate);
    }
  };
  
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Card style={styles.card}>
        <Card.Content>
          <Text style={styles.title}>إضافة معاملة جديدة</Text>
          
          <Text style={styles.sectionTitle}>الحساب المرسل</Text>
          <Picker
            selectedValue={fromAccount}
            onValueChange={setFromAccount}
            style={styles.picker}
          >
            <Picker.Item label="اختر الحساب المرسل" value="" />
            {accounts.filter(a => a.type === 'أصول' || a.type === 'مصروفات').map(account => (
              <Picker.Item 
                key={account.id} 
                label={account.name} 
                value={account.id} 
              />
            ))}
          </Picker>
          
          <Text style={styles.sectionTitle}>الحساب المستقبل</Text>
          <Picker
            selectedValue={toAccount}
            onValueChange={setToAccount}
            style={styles.picker}
          >
            <Picker.Item label="اختر الحساب المستقبل" value="" />
            {accounts.filter(a => a.type === 'أصول' || a.type === 'إيرادات').map(account => (
              <Picker.Item 
                key={account.id} 
                label={account.name} 
                value={account.id} 
              />
            ))}
          </Picker>
          
          <TextInput
            label="المبلغ"
            value={amount}
            onChangeText={setAmount}
            mode="outlined"
            style={styles.input}
            keyboardType="numeric"
            right={<TextInput.Icon name="cash" />}
          />
          
          <TextInput
            label="الوصف"
            value={description}
            onChangeText={setDescription}
            mode="outlined"
            style={styles.input}
            multiline
            numberOfLines={3}
          />
          
          <Text style={styles.sectionTitle}>تاريخ المعاملة</Text>
          <Button 
            mode="outlined" 
            onPress={() => setShowDatePicker(true)}
            style={styles.dateButton}
            icon="calendar"
          >
            {date.toLocaleDateString('ar-EG')}
          </Button>
          
          {showDatePicker && (
            <DateTimePicker
              value={date}
              mode="date"
              display="default"
              onChange={onChangeDate}
            />
          )}
          
          <Button 
            mode="contained" 
            onPress={handleSave} 
            style={styles.button}
            loading={loading}
            disabled={loading}
          >
            حفظ المعاملة
          </Button>
        </Card.Content>
      </Card>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 10,
  },
  card: {
    marginBottom: 15,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'right',
  },
  picker: {
    marginBottom: 15,
    backgroundColor: '#f5f5f5',
  },
  input: {
    marginBottom: 15,
  },
  dateButton: {
    marginBottom: 15,
  },
  button: {
    marginTop: 10,
    paddingVertical: 5,
  },
});

export default AddTransactionScreen;
