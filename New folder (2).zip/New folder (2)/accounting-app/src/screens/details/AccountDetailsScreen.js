import React, { useContext, useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Alert } from 'react-native';
import { Text, Card, Button, Divider, ActivityIndicator } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { DataContext } from '../../context/DataContext';

const AccountDetailsScreen = ({ route, navigation }) => {
  const { accountId } = route.params;
  const { accounts, transactions, updateAccount, deleteAccount } = useContext(DataContext);
  const [account, setAccount] = useState(null);
  const [accountTransactions, setAccountTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAccountDetails = () => {
      try {
        const foundAccount = accounts.find(acc => acc.id === accountId);
        if (!foundAccount) {
          Alert.alert('خطأ', 'الحساب غير موجود');
          navigation.goBack();
          return;
        }

        setAccount(foundAccount);
        
        // تصفية المعاملات المرتبطة بهذا الحساب
        const relatedTransactions = transactions.filter(
          t => t.fromAccount === accountId || t.toAccount === accountId
        );
        
        setAccountTransactions(relatedTransactions);
      } catch (error) {
        console.error('Error fetching account details:', error);
        Alert.alert('خطأ', 'حدث خطأ أثناء تحميل بيانات الحساب');
      } finally {
        setLoading(false);
      }
    };

    fetchAccountDetails();
  }, [accountId, accounts, transactions]);

  const handleDeleteAccount = async () => {
    try {
      const result = await deleteAccount(accountId);
      
      if (result.success) {
        Alert.alert('نجاح', 'تم حذف الحساب بنجاح');
        navigation.goBack();
      } else {
        Alert.alert('خطأ', result.error || 'فشل حذف الحساب');
      }
    } catch (error) {
      Alert.alert('خطأ', 'حدث خطأ أثناء محاولة حذف الحساب');
      console.error(error);
    }
  };

  if (loading || !account) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator animating={true} size="large" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Card style={styles.accountCard}>
        <Card.Content>
          <View style={styles.accountHeader}>
            <Icon 
              name={account.type === 'أصول' ? 'wallet' : 
                    account.type === 'إيرادات' ? 'trending-up' : 
                    account.type === 'مصروفات' ? 'trending-down' : 'wallet-outline'} 
              size={30} 
              color="#2196F3" 
            />
            <Text style={styles.accountName}>{account.name}</Text>
          </View>
          
          <Divider style={styles.divider} />
          
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>نوع الحساب:</Text>
            <Text style={styles.detailValue}>{account.type}</Text>
          </View>
          
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>الرصيد الحالي:</Text>
            <Text style={[styles.detailValue, styles.balanceValue]}>
              {account.balance} {account.currency}
            </Text>
          </View>
          
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>عدد المعاملات:</Text>
            <Text style={styles.detailValue}>{accountTransactions.length}</Text>
          </View>
        </Card.Content>
      </Card>
      
      <View style={styles.actionsContainer}>
        <Button 
          mode="contained" 
          style={styles.editButton}
          onPress={() => navigation.navigate('AddAccount', { accountId: account.id })}
        >
          تعديل الحساب
        </Button>
        
        <Button 
          mode="outlined" 
          style={styles.deleteButton}
          onPress={handleDeleteAccount}
        >
          حذف الحساب
        </Button>
      </View>
      
      <Text style={styles.transactionsTitle}>المعاملات المرتبطة</Text>
      
      {accountTransactions.length > 0 ? (
        accountTransactions.map((transaction, index) => (
          <Card key={index} style={styles.transactionCard}>
            <Card.Content>
              <View style={styles.transactionHeader}>
                <Text style={styles.transactionAmount}>
                  {transaction.amount} {account.currency}
                </Text>
                <Icon 
                  name={transaction.fromAccount === accountId ? "arrow-up" : "arrow-down"} 
                  size={20} 
                  color={transaction.fromAccount === accountId ? "#f44336" : "#4CAF50"} 
                />
              </View>
              
              <Text style={styles.transactionDescription}>{transaction.description}</Text>
              
              <View style={styles.transactionDetails}>
                <Text style={styles.transactionDate}>
                  {new Date(transaction.date).toLocaleDateString('ar-EG')}
                </Text>
                <Text style={styles.transactionType}>
                  {transaction.fromAccount === accountId ? "صرف" : "إيداع"}
                </Text>
              </View>
            </Card.Content>
          </Card>
        ))
      ) : (
        <View style={styles.noTransactionsContainer}>
          <Icon name="swap-horizontal" size={40} color="#999" />
          <Text style={styles.noTransactionsText}>لا توجد معاملات مرتبطة بهذا الحساب</Text>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  accountCard: {
    marginBottom: 15,
  },
  accountHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    marginBottom: 10,
  },
  accountName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginRight: 10,
  },
  divider: {
    marginVertical: 10,
  },
  detailRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  detailLabel: {
    fontSize: 16,
    color: '#666',
  },
  detailValue: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  balanceValue: {
    color: '#2196F3',
  },
  actionsContainer: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  editButton: {
    flex: 1,
    marginLeft: 5,
  },
  deleteButton: {
    flex: 1,
    marginRight: 5,
  },
  transactionsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'right',
  },
  transactionCard: {
    marginBottom: 10,
  },
  transactionHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  transactionDescription: {
    color: '#666',
    marginBottom: 5,
    textAlign: 'right',
  },
  transactionDetails: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
  },
  transactionDate: {
    color: '#999',
    fontSize: 12,
  },
  transactionType: {
    color: '#999',
    fontSize: 12,
  },
  noTransactionsContainer: {
    alignItems: 'center',
    padding: 20,
  },
  noTransactionsText: {
    marginTop: 10,
    color: '#666',
  },
});

export default AccountDetailsScreen;
