import React, { useState, useContext } from 'react';
import { StyleSheet, View, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { TextInput, Button, Text, Surface } from 'react-native-paper';
import { AuthContext } from '../../context/AuthContext';

const RegisterScreen = ({ navigation }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [loading, setLoading] = useState(false);
  const [secureTextEntry, setSecureTextEntry] = useState(true);
  
  const { register } = useContext(AuthContext);

  const handleRegister = async () => {
    if (!name || !email || !password || !companyName) {
      Alert.alert('خطأ', 'الرجاء إدخال جميع البيانات المطلوبة');
      return;
    }

    setLoading(true);
    
    try {
      const result = await register(name, email, password, companyName);
      
      if (!result.success) {
        Alert.alert('خطأ', result.error || 'فشل إنشاء الحساب. الرجاء المحاولة مرة أخرى.');
      }
    } catch (error) {
      Alert.alert('خطأ', 'حدث خطأ أثناء إنشاء الحساب');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <Surface style={styles.surface}>
        <View style={styles.logoContainer}>
          <Text style={styles.appTitle}>إنشاء حساب جديد</Text>
          <Text style={styles.appSubtitle}>املأ النموذج لإنشاء حسابك</Text>
        </View>
        
        <View style={styles.formContainer}>
          <TextInput
            label="اسم المستخدم"
            value={name}
            onChangeText={setName}
            mode="outlined"
            style={styles.input}
            right={<TextInput.Icon icon="account" />}
          />
          
          <TextInput
            label="البريد الإلكتروني"
            value={email}
            onChangeText={setEmail}
            mode="outlined"
            style={styles.input}
            autoCapitalize="none"
            keyboardType="email-address"
            right={<TextInput.Icon icon="email" />}
          />
          
          <TextInput
            label="كلمة المرور"
            value={password}
            onChangeText={setPassword}
            mode="outlined"
            style={styles.input}
            secureTextEntry={secureTextEntry}
            right={
              <TextInput.Icon 
                icon={secureTextEntry ? "eye" : "eye-off"} 
                onPress={() => setSecureTextEntry(!secureTextEntry)} 
              />
            }
          />
          
          <TextInput
            label="اسم الشركة"
            value={companyName}
            onChangeText={setCompanyName}
            mode="outlined"
            style={styles.input}
            right={<TextInput.Icon icon="office-building" />}
          />
          
          <Button 
            mode="contained" 
            onPress={handleRegister} 
            style={styles.button}
            loading={loading}
            disabled={loading}
          >
            إنشاء حساب
          </Button>
          
          <View style={styles.loginContainer}>
            <Text style={styles.loginText}>لديك حساب بالفعل؟</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Text style={styles.loginLink}>تسجيل الدخول</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Surface>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  surface: {
    padding: 20,
    borderRadius: 10,
    elevation: 4,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  appTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2196F3',
    marginBottom: 5,
  },
  appSubtitle: {
    fontSize: 16,
    color: '#666',
  },
  formContainer: {
    width: '100%',
  },
  input: {
    marginBottom: 15,
  },
  button: {
    marginTop: 10,
    paddingVertical: 8,
  },
  loginContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  loginText: {
    marginRight: 5,
  },
  loginLink: {
    color: '#2196F3',
    fontWeight: 'bold',
  },
});

export default RegisterScreen;
