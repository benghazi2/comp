import React, { useContext, useState } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { Text, Button, Card, Searchbar, ActivityIndicator } from 'react-native-paper';
import { DataContext } from '../../context/DataContext';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const AccountsScreen = ({ navigation }) => {
  const { accounts, isLoading } = useContext(DataContext);
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredAccounts = accounts.filter(account => 
    account.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator animating={true} size="large" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Searchbar
        placeholder="ابحث عن حساب"
        onChangeText={setSearchQuery}
        value={searchQuery}
        style={styles.searchBar}
        inputStyle={{ textAlign: 'right' }}
      />
      
      <FlatList
        data={filteredAccounts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity 
            onPress={() => navigation.navigate('AccountDetails', { accountId: item.id })}
          >
            <Card style={styles.card}>
              <Card.Content>
                <View style={styles.accountHeader}>
                  <Text style={styles.accountName}>{item.name}</Text>
                  <Icon 
                    name={item.type === 'أصول' ? 'wallet' : 
                          item.type === 'إيرادات' ? 'trending-up' : 
                          item.type === 'مصروفات' ? 'trending-down' : 'wallet-outline'} 
                    size={24} 
                    color="#2196F3" 
                  />
                </View>
                <View style={styles.accountDetails}>
                  <Text style={styles.accountType}>النوع: {item.type}</Text>
                  <Text style={styles.accountBalance}>
                    الرصيد: {item.balance} {item.currency}
                  </Text>
                </View>
              </Card.Content>
            </Card>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Icon name="wallet-outline" size={50} color="#999" />
            <Text style={styles.emptyText}>لا توجد حسابات متاحة</Text>
          </View>
        }
      />
      
      <Button 
        mode="contained" 
        style={styles.addButton}
        onPress={() => navigation.navigate('AddAccount')}
      >
        إضافة حساب جديد
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchBar: {
    marginBottom: 10,
  },
  card: {
    marginBottom: 10,
  },
  accountHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  accountName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  accountDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  accountType: {
    color: '#666',
  },
  accountBalance: {
    fontWeight: 'bold',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  addButton: {
    margin: 10,
    paddingVertical: 5,
  },
});

export default AccountsScreen;
