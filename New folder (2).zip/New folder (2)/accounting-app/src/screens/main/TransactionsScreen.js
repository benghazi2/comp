import React, { useContext, useState } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { Text, Button, Card, Searchbar, ActivityIndicator } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { DataContext } from '../../context/DataContext';

const TransactionsScreen = ({ navigation }) => {
  const { transactions, accounts, isLoading } = useContext(DataContext);
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredTransactions = transactions.filter(transaction => 
    transaction.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator animating={true} size="large" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Searchbar
        placeholder="ابحث عن معاملة"
        onChangeText={setSearchQuery}
        value={searchQuery}
        style={styles.searchBar}
        inputStyle={{ textAlign: 'right' }}
      />
      
      <FlatList
        data={filteredTransactions}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => {
          const fromAccount = accounts.find(acc => acc.id === item.fromAccount);
          const toAccount = accounts.find(acc => acc.id === item.toAccount);
          
          return (
            <TouchableOpacity 
              onPress={() => navigation.navigate('TransactionDetails', { transactionId: item.id })}
            >
              <Card style={styles.card}>
                <Card.Content>
                  <View style={styles.transactionHeader}>
                    <Text style={styles.transactionDescription}>{item.description}</Text>
                    <Icon 
                      name={item.fromAccount ? "arrow-up" : "arrow-down"} 
                      size={20} 
                      color={item.fromAccount ? "#f44336" : "#4CAF50"} 
                    />
                  </View>
                  
                  <View style={styles.transactionDetails}>
                    <Text style={styles.transactionAmount}>
                      {item.amount} {toAccount?.currency || fromAccount?.currency || ''}
                    </Text>
                    
                    <Text style={styles.transactionDate}>
                      {new Date(item.date).toLocaleDateString('ar-EG')}
                    </Text>
                  </View>
                  
                  <View style={styles.accountInfo}>
                    {fromAccount && (
                      <Text style={styles.fromAccount}>
                        من: {fromAccount.name}
                      </Text>
                    )}
                    {toAccount && (
                      <Text style={styles.toAccount}>
                        إلى: {toAccount.name}
                      </Text>
                    )}
                  </View>
                </Card.Content>
              </Card>
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Icon name="swap-horizontal" size={50} color="#999" />
            <Text style={styles.emptyText}>لا توجد معاملات متاحة</Text>
          </View>
        }
      />
      
      <Button 
        mode="contained" 
        style={styles.addButton}
        onPress={() => navigation.navigate('AddTransaction')}
      >
        إضافة معاملة جديدة
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchBar: {
    marginBottom: 10,
  },
  card: {
    marginBottom: 10,
  },
  transactionHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  transactionDescription: {
    fontSize: 16,
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'right',
  },
  transactionDetails: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  transactionAmount: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  transactionDate: {
    fontSize: 12,
    color: '#666',
  },
  accountInfo: {
    marginTop: 5,
  },
  fromAccount: {
    fontSize: 12,
    color: '#f44336',
    textAlign: 'right',
  },
  toAccount: {
    fontSize: 12,
    color: '#4CAF50',
    textAlign: 'right',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  addButton: {
    margin: 10,
    paddingVertical: 5,
  },
});

export default TransactionsScreen;
