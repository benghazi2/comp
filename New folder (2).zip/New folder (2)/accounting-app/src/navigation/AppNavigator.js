import React, { useContext } from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { AuthContext } from '../context/AuthContext';

// u0634u0627u0634u0627u062a u0627u0644u0645u0635u0627u062fu0642u0629
import LoginScreen from '../screens/auth/LoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';

// u0634u0627u0634u0627u062a u0627u0644u062au0637u0628u064au0642 u0627u0644u0631u0626u064au0633u064au0629
import DashboardScreen from '../screens/main/DashboardScreen';
import AccountsScreen from '../screens/main/AccountsScreen';
import TransactionsScreen from '../screens/main/TransactionsScreen';
import InvoicesScreen from '../screens/main/InvoicesScreen';
import ClientsScreen from '../screens/main/ClientsScreen';
import ReportsScreen from '../screens/main/ReportsScreen';

// u0634u0627u0634u0627u062a u0627u0644u062au0641u0627u0635u064au0644
import AccountDetailsScreen from '../screens/details/AccountDetailsScreen';
import TransactionDetailsScreen from '../screens/details/TransactionDetailsScreen';
import InvoiceDetailsScreen from '../screens/details/InvoiceDetailsScreen';
import ClientDetailsScreen from '../screens/details/ClientDetailsScreen';

// u0634u0627u0634u0627u062a u0627u0644u0625u0636u0627u0641u0629
import AddAccountScreen from '../screens/add/AddAccountScreen';
import AddTransactionScreen from '../screens/add/AddTransactionScreen';
import AddInvoiceScreen from '../screens/add/AddInvoiceScreen';
import AddClientScreen from '../screens/add/AddClientScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// u0645u0643u062fu0633 u0627u0644u062du0633u0627u0628u0627u062a
const AccountsStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="AccountsList" 
        component={AccountsScreen} 
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="AccountDetails" 
        component={AccountDetailsScreen} 
        options={{ title: 'u062au0641u0627u0635u064au0644 u0627u0644u062du0633u0627u0628' }}
      />
      <Stack.Screen 
        name="AddAccount" 
        component={AddAccountScreen} 
        options={{ title: 'u0625u0636u0627u0641u0629 u062du0633u0627u0628 u062cu062fu064au062f' }}
      />
    </Stack.Navigator>
  );
};

// u0645u0643u062fu0633 u0627u0644u0645u0639u0627u0645u0644u0627u062a
const TransactionsStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="TransactionsList" 
        component={TransactionsScreen} 
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="TransactionDetails" 
        component={TransactionDetailsScreen} 
        options={{ title: 'u062au0641u0627u0635u064au0644 u0627u0644u0645u0639u0627u0645u0644u0629' }}
      />
      <Stack.Screen 
        name="AddTransaction" 
        component={AddTransactionScreen} 
        options={{ title: 'u0625u0636u0627u0641u0629 u0645u0639u0627u0645u0644u0629 u062cu062fu064au062fu0629' }}
      />
    </Stack.Navigator>
  );
};

// u0645u0643u062fu0633 u0627u0644u0641u0648u0627u062au064au0631
const InvoicesStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="InvoicesList" 
        component={InvoicesScreen} 
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="InvoiceDetails" 
        component={InvoiceDetailsScreen} 
        options={{ title: 'u062au0641u0627u0635u064au0644 u0627u0644u0641u0627u062au0648u0631u0629' }}
      />
      <Stack.Screen 
        name="AddInvoice" 
        component={AddInvoiceScreen} 
        options={{ title: 'u0625u0636u0627u0641u0629 u0641u0627u062au0648u0631u0629 u062cu062fu064au062fu0629' }}
      />
    </Stack.Navigator>
  );
};

// u0645u0643u062fu0633 u0627u0644u0639u0645u0644u0627u0621
const ClientsStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="ClientsList" 
        component={ClientsScreen} 
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="ClientDetails" 
        component={ClientDetailsScreen} 
        options={{ title: 'u062au0641u0627u0635u064au0644 u0627u0644u0639u0645u064au0644' }}
      />
      <Stack.Screen 
        name="AddClient" 
        component={AddClientScreen} 
        options={{ title: 'u0625u0636u0627u0641u0629 u0639u0645u064au0644 u062cu062fu064au062f' }}
      />
    </Stack.Navigator>
  );
};

// u0645u0643u062fu0633 u0627u0644u062au0642u0627u0631u064au0631
const ReportsStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="ReportsList" 
        component={ReportsScreen} 
        options={{ headerShown: false }}
      />
    </Stack.Navigator>
  );
};

// u0634u0631u064au0637 u0627u0644u062au0646u0642u0644 u0627u0644u0633u0641u0644u064a
const MainTabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Dashboard') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Accounts') {
            iconName = focused ? 'wallet' : 'wallet-outline';
          } else if (route.name === 'Transactions') {
            iconName = focused ? 'swap-horizontal' : 'swap-horizontal-outline';
          } else if (route.name === 'Invoices') {
            iconName = focused ? 'document-text' : 'document-text-outline';
          } else if (route.name === 'Clients') {
            iconName = focused ? 'people' : 'people-outline';
          } else if (route.name === 'Reports') {
            iconName = focused ? 'bar-chart' : 'bar-chart-outline';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#2196F3',
        tabBarInactiveTintColor: 'gray',
        tabBarLabelStyle: { fontWeight: '600' },
      })}
    >
      <Tab.Screen 
        name="Dashboard" 
        component={DashboardScreen} 
        options={{ 
          title: 'u0627u0644u0631u0626u064au0633u064au0629',
          headerShown: false 
        }}
      />
      <Tab.Screen 
        name="Accounts" 
        component={AccountsStack} 
        options={{ 
          title: 'u0627u0644u062du0633u0627u0628u0627u062a',
          headerShown: false 
        }}
      />
      <Tab.Screen 
        name="Transactions" 
        component={TransactionsStack} 
        options={{ 
          title: 'u0627u0644u0645u0639u0627u0645u0644u0627u062a',
          headerShown: false 
        }}
      />
      <Tab.Screen 
        name="Invoices" 
        component={InvoicesStack} 
        options={{ 
          title: 'u0627u0644u0641u0648u0627u062au064au0631',
          headerShown: false 
        }}
      />
      <Tab.Screen 
        name="Clients" 
        component={ClientsStack} 
        options={{ 
          title: 'u0627u0644u0639u0645u0644u0627u0621',
          headerShown: false 
        }}
      />
      <Tab.Screen 
        name="Reports" 
        component={ReportsStack} 
        options={{ 
          title: 'u0627u0644u062au0642u0627u0631u064au0631',
          headerShown: false 
        }}
      />
    </Tab.Navigator>
  );
};

// u0645u0643u062fu0633 u0627u0644u0645u0635u0627u062fu0642u0629
const AuthStack = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
};

// u0627u0644u062au0646u0642u0644 u0627u0644u0631u0626u064au0633u064a
const AppNavigator = () => {
  const { userToken, isLoading } = useContext(AuthContext);

  if (isLoading) {
    // u064au0645u0643u0646 u0625u0636u0627u0641u0629 u0634u0627u0634u0629 u062au062du0645u064au0644 u0647u0646u0627
    return null;
  }

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {userToken ? (
        <Stack.Screen name="MainApp" component={MainTabNavigator} />
      ) : (
        <Stack.Screen name="Auth" component={AuthStack} />
      )}
    </Stack.Navigator>
  );
};

export default AppNavigator;
