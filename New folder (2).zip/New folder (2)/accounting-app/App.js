import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { Provider as PaperProvider } from 'react-native-paper';
import { I18nManager } from 'react-native';
import { AuthProvider } from './src/context/AuthContext';
import { DataProvider } from './src/context/DataContext';
import AppNavigator from './src/navigation/AppNavigator';

// تفعيل دعم اللغة العربية وتحويل الواجهة للاتجاه من اليمين إلى اليسار
I18nManager.forceRTL(true);

export default function App() {
  return (
    <PaperProvider>
      <AuthProvider>
        <DataProvider>
          <NavigationContainer>
            <AppNavigator />
          </NavigationContainer>
        </DataProvider>
      </AuthProvider>
    </PaperProvider>
  );
}
